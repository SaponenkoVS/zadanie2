package org.example;

import java.util.List;

public class ThreadSort implements Runnable {
    List<Integer> list = null;

    public void run()  {
        sortList(list);
    }

    ThreadSort(List<Integer> list) {
        this.list = list;
    }

    public static void sortList(List<Integer> list) {
        int j;
        boolean flag = true;
        int temp;

        while (flag) {
            flag = false;
            for (j = 0; j < list.size() - 1; j++) {
                if (list.get(j) > list.get(j + 1)) {
                    temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                    flag = true;
                }
            }
        }
    }

}
