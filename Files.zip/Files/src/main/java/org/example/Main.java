package org.example;

import java.io.*;
import java.util.*;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        generateFiles();
        long start1 = System.nanoTime();
        sortFilesUsingOneThread();
        long end1 = System.nanoTime() - start1;
        long start2 = System.nanoTime();
        sortFilesUsingTwoThread();
        long end2 = System.nanoTime() - start2;
        long start3 = System.nanoTime();
        sortFilesUsingThreeThread();
        long end3 = System.nanoTime() - start3;
        long start4 = System.nanoTime();
        sortFilesUsingFourThread();
        long end4 = System.nanoTime() - start4;
        System.out.println(Arrays.toString(new long[]{end1/1000000000, end2/1000000000, end3/1000000000, end4/1000000000}));
    }

    public static void generateFiles() {
        for (int i = 1; i < 2; i++) {
            File file = new File("file " + i);
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            FileWriter fileWriter = null;
            try {
                fileWriter = new FileWriter("file " + i);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Random random = new Random();
            for (int n = 100000; n > 0; n--) {
                try {

                    fileWriter.write(0 + random.nextInt(1000000 - -1000000) + 1000000 + "\r");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }

        }
    }

    public static int sortFilesUsingOneThread() {
        FileReader fileReader = null;
        BufferedReader bufferreader = null;
        try {
            fileReader = new FileReader("file 1");
            bufferreader = new BufferedReader(fileReader);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            String line = null;
            ArrayList<Integer> list = new ArrayList<Integer>();
            while ((line = bufferreader.readLine()) != null) {
                list.add(Integer.parseInt(line));
            }
            ArrayList<Integer> sortedList = sortList(list);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return 1;
    }

    public static ArrayList<Integer> sortList(ArrayList<Integer> list) {
        int j;
        boolean flag = true;
        int temp;

        while (flag) {
            flag = false;
            for (j = 0; j < list.size() - 1; j++) {
                if (list.get(j) > list.get(j + 1)) {
                    temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                    flag = true;
                }
            }
        }
        return list;
    }

    public static int sortFilesUsingTwoThread() {
        FileReader fileReader = null;
        BufferedReader bufferreader = null;
        try {
            fileReader = new FileReader("file 1");
            bufferreader = new BufferedReader(fileReader);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            String line = null;
            ArrayList<Integer> list = new ArrayList<Integer>();
            while ((line = bufferreader.readLine()) != null) {
                list.add(Integer.parseInt(line));
            }
            ThreadSort firstThread = new ThreadSort(list.subList(0, list.size() / 2));
            ThreadSort secondThread = new ThreadSort(list.subList(list.size() / 2, list.size()));
            firstThread.run();
            secondThread.run();
            mergeArrays(new List[]{firstThread.list, secondThread.list}, 2);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return 1;

    }

    public static int sortFilesUsingThreeThread() {
        FileReader fileReader = null;
        BufferedReader bufferreader = null;
        try {
            fileReader = new FileReader("file 1");
            bufferreader = new BufferedReader(fileReader);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            String line = null;
            ArrayList<Integer> list = new ArrayList<Integer>();
            while ((line = bufferreader.readLine()) != null) {
                list.add(Integer.parseInt(line));
            }
            ThreadSort firstThread = new ThreadSort(list.subList(0, list.size() / 3));
            ThreadSort secondThread = new ThreadSort(list.subList(list.size() / 3, list.size() * 2 / 3));
            ThreadSort thirdThread = new ThreadSort(list.subList(list.size() * 2 / 3, list.size()));
            firstThread.run();
            secondThread.run();
            thirdThread.run();
            mergeArrays(new List[]{firstThread.list, secondThread.list, thirdThread.list},3);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return 1;

    }

    public static int sortFilesUsingFourThread() {
        FileReader fileReader = null;
        BufferedReader bufferreader = null;
        try {
            fileReader = new FileReader("file 1");
            bufferreader = new BufferedReader(fileReader);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            String line = null;
            ArrayList<Integer> list = new ArrayList<Integer>();
            while ((line = bufferreader.readLine()) != null) {
                list.add(Integer.parseInt(line));
            }
            ThreadSort firstThread = new ThreadSort(list.subList(0, list.size() / 4));
            ThreadSort secondThread = new ThreadSort(list.subList(list.size() / 4, list.size() / 2));
            ThreadSort thirdThread = new ThreadSort(list.subList(list.size() / 2, list.size() * 3 / 4));
            ThreadSort fourthThread = new ThreadSort(list.subList(list.size() * 3 / 4, list.size()));
            firstThread.run();
            secondThread.run();
            thirdThread.run();
            fourthThread.run();
            mergeArrays(new List[]{firstThread.list, secondThread.list, thirdThread.list, fourthThread.list}, 4);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return 1;

    }

    public static void mergeArrays(List<Integer>[] list, int threads){
        List<Integer> mergedList = new ArrayList<>();
        int[] pointers = new int[list.length];

        while (true){
            boolean allArraysEmpty = true;
            int minValue = Integer.MAX_VALUE;
            int minIndex = - 1;
            for (int i = 0; i< list.length; i++){
                if(pointers[i] < list[i].size()){
                    allArraysEmpty = false;
                    if(list[i].get(pointers[i]) < minValue){
                        minValue = list[i].get(pointers[i]);
                        minIndex = i;
                    }
                }
            }

            if(allArraysEmpty){
                break;
            }
            mergedList.add(minValue);
            pointers[minIndex]++;
        }


        File file = new File("sortowany file " + threads);
        try {
            file.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("sortowany file " + threads);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (Integer cyfra : mergedList){
                try {

                    fileWriter.write(cyfra + "\r");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

        }
    }
}